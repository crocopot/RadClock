from clock import radian_clock

print(f"It is currently {radian_clock()} rad o' clock!")